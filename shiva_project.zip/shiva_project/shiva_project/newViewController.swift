//
//  newViewController.swift
//  shiva_project
//
//  Created by Hari Kiran Nagandla on 18/10/23.
//

import UIKit

class newViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
    }
    
    
    
    
    
    
    
    
    
   
    @IBOutlet weak var sego: UISegmentedControl!
    
    @IBAction func segA(_ sender: Any) {
        var s = sego.selectedSegmentIndex
        switch s {
        case 0:
            self.view.backgroundColor = .cyan
        case 1:
            performSegue(withIdentifier: "b1", sender: self)
            self.view.backgroundColor = .cyan
        case 2:
            performSegue(withIdentifier: "c1", sender: self)
            self.view.backgroundColor = .cyan
        case 3:
            performSegue(withIdentifier: "so1", sender: self)
            self.view.backgroundColor  = .cyan
        default:
            view.backgroundColor = .cyan
        }
        
    }
    

}

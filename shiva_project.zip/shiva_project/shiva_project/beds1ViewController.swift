//
//  beds1ViewController.swift
//  shiva_project
//
//  Created by Hari Kiran Nagandla on 20/10/23.
//

import UIKit

class beds1ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        
        
    }
    
    
    
    
    
}

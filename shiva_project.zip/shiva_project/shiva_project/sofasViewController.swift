//
//  sofasViewController.swift
//  shiva_project
//
//  Created by Hari Kiran Nagandla on 20/10/23.
//

import UIKit
var name2 = String()
var phone2 = String()
var pincode2  = String()
var state2 = String()
var city2 = String()
var housno2 = String()
class sofasViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
    }
//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        
//    }
    
    
    @IBOutlet weak var plcl: UILabel!
    
    @IBAction func orderplac(_ sender: Any) {
        plcl.text = "Hurray! your order got placed to this address.  Your name is: \(name2) Your phone number is: \(phone2) your pincode is: \(pincode2) your state name is: \(state2) your city name is: \(city2)  and your house no is: \(housno2)"
    }
    
    
    
    
    
    @IBOutlet weak var slio: UISlider!
    
    @IBOutlet weak var slil: UILabel!
    
    @IBAction func slia(_ sender: Any) {
       let slival = Int(slio.value)
        slil.text = String(slival)
    }
    
    @IBOutlet weak var lbl: UILabel!
    
    
   
    
    
    @IBAction func sub(_ sender: Any) {
        var lk = tg1.text
        
        lbl.text  = "Thanks for your Valuable feedback and your feedback taking into consideration Visit Again \(lk!)"
    }
    
    
    @IBOutlet weak var tg1: UITextField!
    
    
}

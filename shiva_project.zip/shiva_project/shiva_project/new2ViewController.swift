//
//  new2ViewController.swift
//  shiva_project
//
//  Created by Hari Kiran Nagandla on 19/10/23.
//

import UIKit

class new2ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
       
        // Do any additional setup after loading the view.
    }
    
    
    
    
    @IBOutlet weak var seguo: UISegmentedControl!
    
    @IBAction func segA2(_ sender: Any) {
        var u = seguo.selectedSegmentIndex
        switch(u){
        case 0:
            self.view.backgroundColor = .cyan
        case 1:
            performSegue(withIdentifier: "g1", sender: self)
            self.view.backgroundColor = .cyan
        case 2:
            performSegue(withIdentifier: "p1", sender: self)
            self.view.backgroundColor = .cyan
        default:
            view.backgroundColor = .cyan
        }
    }
    

}

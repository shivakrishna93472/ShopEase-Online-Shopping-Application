//
//  new1ViewController.swift
//  shiva_project
//
//  Created by Hari Kiran Nagandla on 19/10/23.
//

import UIKit

class new1ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        
    }
    
    
    @IBOutlet weak var segeo: UISegmentedControl!
    @IBAction func segA1(_ sender: Any) {
        var e = segeo.selectedSegmentIndex
        switch(e){
        case 0:
            self.view.backgroundColor = .cyan
        case 1:
            performSegue(withIdentifier: "a1", sender: self)
            self.view.backgroundColor = .cyan
        case 2:
            performSegue(withIdentifier: "r1", sender: self)
            self.view.backgroundColor = .cyan
        case 3:
            performSegue(withIdentifier: "sm1", sender: self)
            self.view.backgroundColor  = .cyan
        default:
            view.backgroundColor = .cyan
        }
    }
    
}

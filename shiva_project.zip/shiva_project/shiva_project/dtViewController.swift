//
//  dtViewController.swift
//  shiva_project
//
//  Created by pawanjit kumar on 29/10/23.
//

import UIKit
var data1 = String()
class dtViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        lbl3.text = "Welcome    \(data1)"
    }
    
    @IBOutlet weak var lbl3: UILabel!
    
}

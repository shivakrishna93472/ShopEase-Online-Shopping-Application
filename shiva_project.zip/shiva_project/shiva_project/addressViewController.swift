//
//  addressViewController.swift
//  shiva_project
//
//  Created by Hari Kiran Nagandla on 28/10/23.
//

import UIKit

class addressViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var na1: UITextField!
    @IBOutlet weak var ph1: UITextField!
    @IBOutlet weak var pin1: UITextField!
    
    @IBOutlet weak var sta1: UITextField!
    
    @IBOutlet weak var cit1: UITextField!
    
    @IBOutlet weak var hou1: UITextField!
    
    
    
    
    @IBAction func submitadd(_ sender: Any) {
        name2 = na1.text!
        phone2  = ph1.text!
        pincode2 = pin1.text!
        state2 = sta1.text!
        city2 = cit1.text!
        housno2 = hou1.text!
        
        
        var al1 = {
            (ACTION:UIAlertAction) -> Void in
            self.view.backgroundColor = UIColor.blue
        }
        
        var alert2 = UIAlertController(title: "Address Message", message: "Your Address Saved Successfully", preferredStyle: .alert)
        alert2.addAction(UIAlertAction(title: "ok", style: .default, handler: al1))
        self.present(alert2, animated: true,completion: nil)
    }
    
    
    
    
}

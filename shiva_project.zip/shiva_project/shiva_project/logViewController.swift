//
//  logViewController.swift
//  shiva_project
//
//  Created by Hari Kiran Nagandla on 28/10/23.
//

import UIKit

class logViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var text1: UITextField!
    
    @IBOutlet weak var passw1: UITextField!
    
    @IBAction func auth(_ sender: Any) {
        username2 = text1.text!
        password2 = passw1.text!
        performSegue(withIdentifier: "login", sender: self)
    }
    
    
    
    
    

    
    @IBOutlet weak var web1: UIWebView!

    @IBAction func watch(_ sender: Any) {
        var urlstr = URL(string: "https://youtu.be/WkbtvG4DKto")
        var urlreq = URLRequest(url: urlstr!)
        web1.loadRequest(urlreq)
        
    }
    
    
    
    
}

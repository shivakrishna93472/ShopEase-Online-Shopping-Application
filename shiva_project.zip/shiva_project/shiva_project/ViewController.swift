//
//  ViewController.swift
//  shiva_project
//
//  Created by Hari Kiran Nagandla on 17/10/23.
//

import UIKit
var username2 = String("abc")
var password2 = String("abc")
class ViewController: UIViewController {
    var name = String()
    var passwd = String()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var lb1: UILabel!
    @IBOutlet weak var lb2: UILabel!
    @IBOutlet weak var lb3: UILabel!
    
    @IBOutlet weak var tf1: UITextField!
    @IBOutlet weak var tf2: UITextField!
    
    
    @IBAction func loginb(_ sender: Any) {
        name = tf1.text!
        passwd = tf2.text!
        data1 = tf1.text!
        
        if((name == "shiva" && passwd == "1234") || (name == "hari" && passwd == "5678") || (name == "admin" && passwd == "1111") || (name == username2 && passwd == password2)){
            performSegue(withIdentifier: "s1", sender: self)
            
        }else{
            
            var hand = {
                (ACTION:UIAlertAction) -> Void in
                self.im.image = UIImage(named: "bg5")
            }
            var hand1 = {
                (ACTION:UIAlertAction) -> Void in
                self.im.image = UIImage(named: "bg2")
            }
            
            
            
            var alert1 = UIAlertController(title: "Warning", message: "you entered a wrong password", preferredStyle: .actionSheet)
            alert1.addAction(UIAlertAction(title: "Try Once Again", style: .default, handler: hand))
            alert1.addAction(UIAlertAction(title: "Cancel", style: .default, handler: hand1))
            self.present(alert1,animated: true,completion: nil)
        }
    }
    
    @IBOutlet weak var im: UIImageView!
    
    


}

